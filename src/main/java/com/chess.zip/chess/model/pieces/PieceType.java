package com.chess.model.pieces;

public enum PieceType {
    KING, 
    QUEEN,
    BISHOP,
    KNIGHT,
    ROOK,
    PAWN;
}
