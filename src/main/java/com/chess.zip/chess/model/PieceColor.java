package com.chess.model;

public enum PieceColor {
    BLACK,
    WHITE;
}
